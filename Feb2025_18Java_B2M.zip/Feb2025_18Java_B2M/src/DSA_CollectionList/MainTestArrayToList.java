package DSA_CollectionList;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainTestArrayToList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Integer arrtest[] = {1,2,3,4,5,6,67,7};
		
//        List<Integer> lst6 = new <Integer> ArrayList();
//        
//        lst6 = Arrays.asList(455,900,897,7876,999);
//        System.out.println(lst6);
		
		Integer arrval[] = {78,89,56,9,89,11,34,89,7686,90,56};
		List <Integer>lst5 =
				Arrays.asList(arrval);
		System.out.println(lst5);
		
				
				
        
        
        
        
        
        
        
        
        
        

	}

}
