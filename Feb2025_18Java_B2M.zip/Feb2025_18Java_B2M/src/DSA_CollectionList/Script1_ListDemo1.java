package DSA_CollectionList;

import java.util.ArrayList; // class
import java.util.Arrays;
import java.util.Iterator;
import java.util.List; // interface
import java.util.Scanner;

public class Script1_ListDemo1 {
	int numberscount = 7;
	int test[] = new int[numberscount];
	
	public static void CreateAnEmptyList() {
		
		List lst = new ArrayList(); 
		
		System.out.println(lst);
		
	}
	
	public static void CreateAListOfNames() {
		
		List <String> lst1 = 
				new ArrayList();
		
		lst1.add("Prateek");
		lst1.add("Prachi");
		lst1.add("Mohan");
		lst1.add("John");
		
	   System.out.println("The name list is :" + " "+lst1 );	
		
		
	}
	
	
	public static void TakeDataFromArrayToList() {
		Integer arr [] = {67,65,90,45,67,22,45,99};
		
		// Get the data from array and store in list
		
		
		
		
		List  lst3 = Arrays.asList( arr);
		
		System.out.println(lst3); // traversal not
		

		
	}
	
	public  void TakeInputforList() {
		
		Scanner c = new Scanner(System.in);
		

		
		List lst6 = new ArrayList();
		
		for(int j=0;j<test.length-1;j++) {
			
			 lst6.add(c.nextInt());
		}
		
		System.out.println(lst6);
	
		
	}
	
	
	public void ListTraversalDemo() {
		
		String id[] = {"112","545","675","234"};
		
		List <String> empid = Arrays.asList(id);
		
		Iterator it = empid.iterator();
		
		System.out.println("*********************************");
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
		
		
		String rest1 =empid.get(3);
		System.out.println(rest1); //234
			
	}
	
	//List Data Validation
	
	public boolean ValidateDataInList() {
		
		List <Integer> lst7 = Arrays.asList(45,34,9045,89,13,899,565,1010);
		boolean res = lst7.contains(34);
	
		return res;
		
		
	}
	
	
	

}
