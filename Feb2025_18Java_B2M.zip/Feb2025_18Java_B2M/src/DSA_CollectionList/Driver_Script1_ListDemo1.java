package DSA_CollectionList;

public class Driver_Script1_ListDemo1 extends Script1_ListDemo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Driver_Script1_ListDemo1 t1 = new Driver_Script1_ListDemo1();
		
		CreateAnEmptyList();
//		
//		CreateAListOfNames();
//		
//		TakeDataFromArrayToList();
//		//t1.TakeInputforList();
//		
//		t1.TakeInputforList();
//		t1.ListTraversalDemo();
		boolean res2=t1.ValidateDataInList();
		System.out.println(res2);
	}

}
