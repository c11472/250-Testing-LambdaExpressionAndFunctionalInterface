package FunctionalInterfaceDemo;

public interface FunctionalInterfaceWithParam {
	
	abstract int GetSum(int n , int n2 , int num3);

}
