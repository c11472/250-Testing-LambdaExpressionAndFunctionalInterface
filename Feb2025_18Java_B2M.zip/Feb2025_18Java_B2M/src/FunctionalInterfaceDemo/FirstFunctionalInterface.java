package FunctionalInterfaceDemo;
@FunctionalInterface
public interface FirstFunctionalInterface {
	
	abstract void displaydata(); 
	// new feature default method
	default void SayHello() {
		System.out.println("Hello All !");
	}
	
	//static method
	
	static void teststatic() {
		System.out.println("This is a static method inside functional interface");
	}
	
	
}
