package FunctionalInterfaceDemo;

public class DefineContracts {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		FirstFunctionalInterface ref = ()->
			
			System.out.println("This is the first "
					+ "lambda experession");
			
		// Invoke the method
		
			ref.displaydata();
			
			// invoke the default method
			ref.SayHello();
			// call the static method
			FirstFunctionalInterface.teststatic();
			
			
			
			
			SecondFunctionalInterface ref2 = () -> {
			   String str = "Hello All !";
			   return str;
			};
			
			
			
			String result = ref2.contract2();
			
			System.out.println(result);
			FunctionalInterfaceWithParam ref3 = (int a , int b ,int c)->{
				int sum = a+ b+c;
				return sum;
				
			};
			
			
			int resultCalculate = ref3.GetSum(6, 6, 6);
			System.out.println(resultCalculate);
			
			
			
			FunctionalInterfaceWithParam ref4 = (int x , int y ,int z)->{
				
				
				int sum1 = x+ y+z;
				return sum1;
				
			};
			
			int resultCalculate1 = ref4.GetSum(1, 2, 3);
			
			System.out.println(resultCalculate1);
			   
	}
}
