package FunctionalInterfaceDemo;
@FunctionalInterface
public interface SecondFunctionalInterface {
	
	abstract  String contract2();

}
