package StreamDemo;

import java.util.Arrays;
import java.util.List;

public class Script1_ConvertListToStream {
	
	public static void main(String[] args) {
		
		// Create a list and store the elements as numbers
		
		List <Integer> list1 = Arrays.asList(12,45,900,4,25,34,145,256);
		
		//print the list content
		
		System.out.println("The valuse in list1 :" + " " + list1);
		
		//count method
		
		int noofelements = (int) list1.stream().count();
		System.out.println("Total number of elements"+" "+ noofelements);
		
		// fetch the data
		
		list1.stream().forEach(System.out::println);
		
		//use condition to filter the data
		
		// list,stream,filter,forEach
		
	
		
		
		
		
	}

}
