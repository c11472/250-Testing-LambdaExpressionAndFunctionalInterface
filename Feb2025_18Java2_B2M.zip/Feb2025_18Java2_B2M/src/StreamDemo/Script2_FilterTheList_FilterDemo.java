package StreamDemo;

import java.util.Arrays;
import java.util.List;

/*******
 * Filter the list to display only even numbers
 * 
 * @author Hp
 *
 */

public class Script2_FilterTheList_FilterDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//1
		List <Integer> list2 = Arrays.asList(1,8,27,45,2,36,3,99,4,90,5,75);
		
		List <Integer> list3 = Arrays.asList(1,10,20,30,40,15);
		// use stream
		//use filter to process the condition in terms of lambda expression
		
		//Display the output
		
		list2.stream().filter(n -> n%2!=0).forEach(System.out::println);
		
		
		
		
		//count even numbers
		int counteveninlist=(int) list2.stream().filter(n -> n%2==0).count();
		System.out.println("even count" + " " +counteveninlist);
		
		list3.stream().filter(n1 -> n1%2!=0).forEach(System.out::println);
		
		//Store the output in a different collection

		
	}

}
