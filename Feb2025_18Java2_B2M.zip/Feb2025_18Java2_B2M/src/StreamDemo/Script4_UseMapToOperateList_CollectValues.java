package StreamDemo;
/***
 * Add 20 to each elements presnt in the list and store the result in a new list
 * 
 */

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Script4_UseMapToOperateList_CollectValues {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List <Integer> list2 = Arrays.asList(1,8,27,45,2,36,3,99,4,90,5,75);
		
		List <Integer> list4 = new ArrayList(); // emptyList
		
		// Process list2
		
		list2.stream().map(n ->n+20).forEach(System.out::println);
		
		// Add 20 to all even numbers in list
		
		System.out.println("The output after filter and map");
		
		list2.stream().filter(n1->n1%2==0).map(n2->n2+20).forEach(System.out::println);
		
	}

}
