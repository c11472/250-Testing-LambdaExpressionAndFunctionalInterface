package StreamDemo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Script3_FilterTheList_CollectValues {
	
	/******
	 * 
	 * Load the data from existing list to an empty list using collect
	 * @param args
	 */

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List <Integer> list2 = Arrays.asList(1,8,27,45,2,36,3,99,4,90,5,75);
		
		
		// resultant list
		List <Integer> list3 = new ArrayList(); //empty list
		
		//process the first list list2
		
		list3 =list2.stream().collect(Collectors.toList());
		
		//traverse the resultant list
		System.out.println("resultant list");
		
		for(int i:list3) {
			System.out.print(i+ " ");
		}
		
	}

}
