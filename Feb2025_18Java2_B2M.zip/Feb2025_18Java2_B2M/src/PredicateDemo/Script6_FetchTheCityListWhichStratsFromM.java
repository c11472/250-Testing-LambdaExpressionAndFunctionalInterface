package PredicateDemo;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class Script6_FetchTheCityListWhichStratsFromM {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List <String> Cities =
				new ArrayList();
		
		// Add city to cities list
		Cities.add("Mumbai");
		Cities.add("Delhi");
		Cities.add("Trichi");
		Cities.add("Mangalore");
		Cities.add("Kochine");
		Cities.add("Cuttack");
		Cities.add("Msore");
		
		System.out.println(Cities);
		
		// define the predicate
		
		Predicate<String> p = city -> city.startsWith("M");
		
		// Filter List
		
		List<String> lstcity=Cities.stream().filter(p).collect(Collectors.toList());
		System.out.println("Result *****");
		
		System.out.println(lstcity);
		
		// add Valid to each resultant elements in list
		System.out.println("Result2 with map");
		List <String> lstf1=lstcity.stream().map(n1 -> n1.concat("Valid")).collect(Collectors.toList());
		
		System.out.println(lstf1);
		
		//System.out.println("Before filter: " + Cities);
	
	}

}
