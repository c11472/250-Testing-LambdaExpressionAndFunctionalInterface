package PredicateDemo;

import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class Script5_UsePredicate_With_Filter {
	
	public static void main(String[] args) {
		
		List <Integer> list1 = Arrays.asList(12,45,900,4,25,34,145,256);
		
		// p1 is the predicate of type Integer which holds the conditional lambda
		
		Predicate <Integer> p1 = n -> n%2==0;
		
		Predicate <Integer> p2 = n -> n%2!=0;
		
		Predicate <Integer> p3 = n -> n<145;
		
		// Filter the even numbers from list1 using p1
		
		
		List  <Integer> r1=list1.stream().filter(p1).collect(Collectors.toList());
		System.out.println("Even numbers are: " + r1);
		
		List  <Integer> r2=list1.stream().filter(p2).collect(Collectors.toList());
		System.out.println("Odd numbers are: " + r2);
		
		List  <Integer> r3=list1.stream().filter(p3).collect(Collectors.toList());
		System.out.println("Numbers less than 145 are: " + r3);
	
	}
}
